# coding:utf8
import pygame
import sys
from poo_perso import *

'''Stage de test fonctionnel
BB Fevrier 2025
Avec les fonctions de BL'''

# Initialisation de la fenêtre principale
pygame.init()
fen = pygame.display.set_mode((1000,650))
pygame.display.set_caption('Courbet Fighter Z')

# Couleurs
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (200, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)

# Police
font = pygame.font.Font(None, 40)

# Musique
pygame.mixer.music.load("ambiance.mp3")
pygame.mixer.music.play(-1)

# FPS
clock = pygame.time.Clock()

# Charger les images d'attaque (assurez-vous d'avoir ces fichiers dans votre dossier)
attaque_image = pygame.image.load("attak.png")  # Image pour l'attaque normale
attaque_speciale_image = pygame.image.load("attak.png")  # Image pour l'attaque spéciale

def afficher_victoire(gagnant):
    '''Affiche l'écran de victoire avec un bouton RETRY'''
    fGagne = pygame.image.load("fondGagne.png").convert()
    en_cours = True
    while en_cours:
        fen.blit(fGagne, (0, 0))
        texte = font.render(f"{gagnant} WINS!", True, WHITE)
        fen.blit(texte, (400, 250))

        retry_button = pygame.draw.rect(fen, GREEN, (400, 350, 200, 80))
        fen.blit(font.render("RETRY", True, BLACK), (450, 380))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN and retry_button.collidepoint(event.pos):
                return  # Redémarrer la partie

        pygame.display.flip()

def jeu(fond_t):
    if fond_t:
        try:
            fond = pygame.image.load(fond_t).convert()
        except pygame.error:
            print(f"Erreur : Impossible de charger l'image '{fond_t}', fond noir utilisé.")
            fond = pygame.Surface((1000, 650))
            fond.fill(WHITE)
    else:
        fond = pygame.Surface((1000, 650))
        fond.fill(WHITE)

    p1 = Personnage(200, 500, RED, gauche=True)
    p2 = Personnage(750, 500, BLUE, gauche=False)

    en_cours = True
    while en_cours:
        fen.blit(fond, (0, 0))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return
                if event.key == pygame.K_r and p1.ki >= 20:
                    p1.attaque_speciale()
                    p1.ki -= 20
                if event.key == pygame.K_i and p2.ki >= 20:
                    p2.attaque_speciale()
                    p2.ki -= 20

        touches = pygame.key.get_pressed()

        if touches[pygame.K_e]:
            p1.attaque_en_cours = True
            pygame.draw.rect(fen, WHITE, (p1.rect.x + 50, p1.rect.y + 20, 20, 20))
            if (p1.rect.x + 70 >= p2.rect.x and p1.rect.x < p2.rect.x and abs(p1.rect.y - p2.rect.y) < 20):
                p2.vie -= 0.8
        else :
            p1.attaque_en_cours = False

        if touches[pygame.K_p]:
            p2.attaque_en_cours = True
            pygame.draw.rect(fen, WHITE, (p2.rect.x - 20, p2.rect.y + 20, 20, 20))
            if (p2.rect.x - 20<= p1.rect.x + 50 and p2.rect.x > p1.rect.x and abs(p2.rect.y - p1.rect.y) < 20):
                p1.vie -= 0.8
        else:
            p2.attaque_en_cours = False

        if p1.attaque_speciale_en_cours:
            pygame.draw.rect(fen, GREEN, (p1.rect.x + 60, p1.rect.y + 20, 40, 20))
            if (p1.rect.x + 100 >= p2.rect.x and p1.rect.x < p2.rect.x and abs(p1.rect.y - p2.rect.y) < 20):
                p2.vie -= 30
            p1.attaque_special_en_cours = False

        if p2.attaque_speciale_en_cours:
            pygame.draw.rect(fen, GREEN, (p2.rect.x - 40, p2.rect.y + 20, 40, 20))
            if (p2.rect.x - 40 <= p1.rect.x + 50 and p2.rect.x > p1.rect.x and abs(p2.rect.y - p1.rect.y) < 20):
                p1.vie -= 30
            p2.attaque_special_en_cours = False

        p1.deplacer(touches, pygame.K_q, pygame.K_d, pygame.K_z)
        p2.deplacer(touches, pygame.K_k, pygame.K_m, pygame.K_o)
        p1.recharge(touches, pygame.K_s)
        p2.recharge(touches, pygame.K_l)

        if p1.vie <= 0:
            afficher_victoire("JOUEUR 2")
            return
        if p2.vie <= 0:
            afficher_victoire("JOUEUR 1")
            return

        p1.dessiner()
        p2.dessiner()

        # Barre KI
        pygame.draw.rect(fen, WHITE, (10, 10, 100, 10))
        pygame.draw.rect(fen, BLUE, (10, 10, p1.ki, 10))
        pygame.draw.rect(fen, WHITE, (890, 10, 100, 10))
        pygame.draw.rect(fen, RED, (990 - p2.ki, 10, p2.ki, 10))

        fps_text = font.render(f"FPS: {int(clock.get_fps())}", True, WHITE)
        fen.blit(fps_text, (10, 620))

        pygame.display.flip()
        clock.tick(60)
