#coding:utf8

'''Projet de fin d'année
Courbet Fighter Z
Class Personnage de test
BB Janvier 2025'''

###imports
import pygame

pygame.init()
fen = pygame.display.set_mode((1000, 650))

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (200, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)

class Personnage:
    '''Classe test d'un personnage de CFZ'''
    def __init__(self, x, y, couleur, gauche=True):
        #sprite/hitbox perso
        self.image = pygame.image.load("pers.png").convert_alpha()
        self.im_attaque = pygame.image.load("attak.png").convert_alpha()  
        self.rect = pygame.Rect(x, y, 40, 200)  #ajout de l'hitbox
        #infos pratique
        self.couleur = couleur
        self.vitesse = 5
        self.velocity = 10
        self.acceleration = 0.1
        self.vie = 100
        self.ki = 0
        self.attaque_en_cours = False
        self.attaque_speciale_en_cours = False
        self.gauche = gauche  # Orientation initiale

    def deplacer(self, touches, gauche_key, droite_key, haut_key):
        '''Permet au personnage de se déplacer'''
        if touches[gauche_key] and self.rect.left > 0:
            self.rect.x -= self.vitesse
            self.gauche = True
        if touches[droite_key] and self.rect.right < 1000:
            self.rect.x += self.vitesse
            self.gauche = False
        if touches[haut_key] and self.rect.top > 0:
            self.rect.y -= self.vitesse

        self.rect.y += self.velocity
        self.velocity += self.acceleration

        if self.rect.bottom >= 650:
            self.rect.bottom = 650
            self.velocity = 0
        if self.rect.top < 0:
            self.rect.top = 0
            self.velocity = 0

        if touches[haut_key] and self.rect.bottom >= 650:
            self.velocity = -25

    def attaquer(self):
        '''Vérifie si le personnage attaque'''
        self.attaque_en_cours = True

    def attaque_speciale(self):
        '''Regarde si l'attaque spéciale est active'''
        if self.ki >= 20:
            self.ki -= 20
            self.attaque_speciale_en_cours = True

    def recharge(self, touches, bas_key):
        '''Recharge le ki'''
        if touches[bas_key] and self.ki < 100:
            self.ki += 0.1
    
    def dessiner(self):
        '''dessine le personnage'''
        #vérifie si le personnage attaque ou pas (alterne les sprites)
        if self.attaque_en_cours or self.attaque_speciale_en_cours :
            im = self.im_attaque
        else:
            im = self.image
        #permet d'orienter le sprite du personnage
        if self.gauche:
            im = pygame.transform.flip(im, True, False)
        #affiche le personnage et la barre de vie
        
        im_rect = im.get_rect(center=self.rect.center)
        fen.blit(im, im_rect.topleft)
        pygame.draw.rect(fen, (0, 255, 0), (self.rect.x, self.rect.y - 15, self.vie, 10))
        #debugs hitbox
        #pygame.draw.rect(fen, self.couleur, self.rect) #hitbox complete
        pygame.draw.rect(fen, (255, 0, 0), self.rect, 2)  #hitbox partielle

