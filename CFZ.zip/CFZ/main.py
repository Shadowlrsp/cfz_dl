# coding:utf8
import pygame
import sys
from poo_perso import *
from stage_test import *

'''Fenêtre principale
BL Février 2025'''

# Initialisation
pygame.init()
fen = pygame.display.set_mode((1000,650))
pygame.display.set_caption('Courbet Fighter Z')

# Fonds
tfMain = pygame.image.load("fondMain.png").convert()
tfOption = pygame.image.load("fondOption.png").convert()

# Couleurs
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (200, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)

# Police
font = pygame.font.Font(None, 40)

# Musique
volume = 1.0
fps = 60
pygame.mixer.music.load("ambiance.mp3")
pygame.mixer.music.set_volume(volume)
pygame.mixer.music.play(-1)

# Fonction options
def options():
    '''Affiche la fenêtre des options avec réglage du volume et des FPS'''
    global fps, volume  # Permet de modifier les valeurs globales
    temp_volume = volume
    temp_fps = fps
    
    en_cours = True
    while en_cours:
        fen.blit(tfOption, (0, 0))
        fen.blit(font.render("OPTIONS", True, WHITE), (400, 150))
        
        volume_down = pygame.draw.rect(fen, RED, (300, 250, 50, 50))
        fen.blit(font.render("-", True, WHITE), (320, 260))

        volume_up = pygame.draw.rect(fen, GREEN, (550, 250, 50, 50))
        fen.blit(font.render("+", True, WHITE), (570, 260))
        
        fen.blit(font.render(f"Volume: {int(temp_volume * 100)}%", True, WHITE), (375, 260))
        
        fps_down = pygame.draw.rect(fen, RED, (300, 350, 50, 50))
        fen.blit(font.render("-", True, WHITE), (320, 360))
        
        fps_up = pygame.draw.rect(fen, GREEN, (550, 350, 50, 50))
        fen.blit(font.render("+", True, WHITE), (570, 360))
        
        fen.blit(font.render(f"FPS: {temp_fps}", True, WHITE), (375, 360))
        
        apply_button = pygame.draw.rect(fen, WHITE, (300, 450, 200, 50))
        fen.blit(font.render("APPLIQUER", True, BLACK), (320, 460))
        
        back_button = pygame.draw.rect(fen, BLUE, (550, 450, 200, 50))
        fen.blit(font.render("RETOUR", True, WHITE), (610, 460))
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if volume_down.collidepoint(event.pos) and temp_volume > 0.1 :
                    temp_volume -= 0.1
                elif volume_up.collidepoint(event.pos) and temp_volume < 1:
                    temp_volume += 0.1
                elif fps_down.collidepoint(event.pos) and temp_fps > 30:
                    temp_fps -= 10
                elif fps_up.collidepoint(event.pos) and temp_fps < 120:
                    temp_fps += 10
                elif apply_button.collidepoint(event.pos):
                    volume = temp_volume
                    fps = temp_fps
                    pygame.mixer.music.set_volume(volume)
                elif back_button.collidepoint(event.pos):
                    return
        
        pygame.display.flip()


def selection_stage():
    '''Affiche le menu de choix du stage'''
    while True:
        fen.fill(BLACK)
        fen.blit(font.render("CHOISISSEZ UN STAGE", True, WHITE), (350, 200))
        
        stage1_button = pygame.draw.rect(fen, BLUE, (350, 300, 300, 50))
        fen.blit(font.render("FOND CLASSIQUE", True, WHITE), (380, 310))
        
        stage2_button = pygame.draw.rect(fen, RED, (350, 400, 300, 50))
        fen.blit(font.render("FOND DE TEST", True, WHITE), (380, 410))
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if stage1_button.collidepoint(event.pos):
                    jeu("fondStage.png")
                    return
                elif stage2_button.collidepoint(event.pos):
                    jeu(None)
                    return
        
        pygame.display.flip()

# Lancement du jeu
def lanceur():
    while True:
        fen.blit(tfMain, (0, 0))
        start_button = pygame.draw.rect(fen, GREEN, (375, 300, 225, 100))
        fen.blit(font.render('START', True, BLACK), (443, 340))
        
        options_button = pygame.draw.rect(fen, WHITE, (100, 450, 225, 100))
        fen.blit(font.render('OPTIONS', True, BLACK), (150, 490))
        
        quit_button = pygame.draw.rect(fen, RED, (700, 450, 225, 100))
        fen.blit(font.render('QUIT', True, BLACK), (780, 490))
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if start_button.collidepoint(event.pos):
                    selection_stage()
                elif options_button.collidepoint(event.pos):
                    options()
                elif quit_button.collidepoint(event.pos):
                    pygame.quit()
                    sys.exit()
        
        pygame.display.flip()

lanceur()
